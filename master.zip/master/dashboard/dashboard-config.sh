#!/bin/bash
if [ ! -f dashboard-key.pem ] && [ ! -f dashboard.pem ];then
    echo -e "\033[31mdashboard-key.pem和dashboard.pem文件不存在\033[0m"
    exit
fi
kubectl create -f dashboard-rbac.yaml 
kubectl create -f dashboard-secret.yaml 
kubectl create -f dashboard-configmap.yaml 
kubectl create -f dashboard-controller.yaml 
kubectl create -f dashboard-service.yaml 
kubectl create -f k8s-admin.yaml

kubectl get pods,svc -n kube-system

echo "https://node_ip:30001"
