#!/bin/bash

TOKEN_NAME=$(kubectl get secret -n kube-system | grep dashboard-admin-token | awk '{print $1}')
kubectl describe secret $TOKEN_NAME -n kube-system | grep token:
