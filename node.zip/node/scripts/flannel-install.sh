#!/bin/bash
DIR=/usr/local/src
[ ! -f $DIR ] && mkdir -p $DIR

cd $DIR && wget https://github.com/coreos/flannel/releases/download/v0.10.0/flannel-v0.10.0-linux-amd64.tar.gz
tar –xf flannel-v0.10.0-linux-amd64.tar.gz
mv flanneld mk-docker-opts.sh /opt/kubernetes/bin/

