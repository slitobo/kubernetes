#!/bin/bash

DOCKER_VERSION=18.06.1.ce-3.el7
yum install -y xfsprogs

yum remove docker \
docker-client \
docker-client-latest \
docker-common \
docker-latest \
docker-latest-logrotate \
docker-logrotate \
docker-selinux \
docker-engine-selinux \
docker-engine
yum-config-manager --add-repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo && \
yum makecache fast && yum install -y docker-ce-$DOCKER_VERSION

[ ! -d /etc/docker ] && mkdir /etc/docker 
cat > /etc/docker/daemon.json <<EOF
{
  "registry-mirrors": ["https://ofjd111b.mirror.aliyuncs.com"]
}
EOF

