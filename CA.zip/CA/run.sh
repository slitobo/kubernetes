#!/bin/bash
# by slitobo 

# 1.安装cfssl
#bash cfssl-install.sh &&
# 2.生成etcd证书
bash etcd-cert.sh
# 3.生成Kubernetes证书
bash kubernetes-cert.sh &&
# 4.生成dashboard证书
bash dashboard-cert.sh $(pwd)/kubernetes-cert


