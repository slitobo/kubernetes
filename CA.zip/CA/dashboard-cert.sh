#!/bin/bash
DASHBOARD_CERT_DIR=./dashboard-cert
[ ! -f $DASHBOARD_CERT_DIR ] && mkdir $DASHBOARD_CERT_DIR
cd $DASHBOARD_CERT_DIR
cat > dashboard-csr.json <<EOF
{
    "CN": "Dashboard",
    "hosts": [],
    "key": {
        "algo": "rsa",
        "size": 2048
    },
    "names": [
        {
            "C": "CN",
            "L": "BeiJing",
            "ST": "BeiJing"
        }
    ]
}
EOF

K8S_CA=$1
cfssl gencert -ca=$K8S_CA/ca.pem -ca-key=$K8S_CA/ca-key.pem -config=$K8S_CA/ca-config.json -profile=kubernetes dashboard-csr.json | cfssljson -bare dashboard
#kubectl delete secret kubernetes-dashboard-certs -n kube-system
#kubectl create secret generic kubernetes-dashboard-certs --from-file=./ -n kube-system


# dashboard-controller.yaml 增加证书两行，然后apply
#        args:
#          # PLATFORM-SPECIFIC ARGS HERE
#          - --auto-generate-certificates
#          - --tls-key-file=dashboard-key.pem
#          - --tls-cert-file=dashboard.pem
